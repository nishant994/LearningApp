package dataDriven;

import fileManager.FileReaderManager;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ExcelUtils {

    private XSSFSheet excelWSheet;

    private XSSFWorkbook excelWBook;

    private XSSFCell cell;

    private XSSFRow row;


//This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method

    public void setExcelFile(String Path,String SheetName) throws Exception {

        try {

            // Open the Excel file

            FileInputStream ExcelFile = new FileInputStream(Path);

            // Access the required test data sheet

            excelWBook = new XSSFWorkbook(ExcelFile);

            excelWSheet = excelWBook.getSheet(SheetName);

        } catch (Exception e){

            throw (e);

        }

    }



//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num

    public  String getCellData(int RowNum, int ColNum) throws Exception{

        try{

            cell = excelWSheet.getRow(RowNum).getCell(ColNum);

            String CellData = cell.getStringCellValue();

            return CellData;

        }catch (Exception e){

            return"";

        }

    }

//This method is to write in the Excel cell, Row num and Col num are the parameters

    public void setCellData(String Result,  int RowNum, int ColNum) throws Exception	{

        try{

            row  = excelWSheet.getRow(RowNum);

            cell = row.getCell(ColNum, row.RETURN_BLANK_AS_NULL);

            if (cell == null) {

                cell = row.createCell(ColNum);

                cell.setCellValue(Result);

            } else {

                cell.setCellValue(Result);

            }

// Constant variables Test Data path and Test Data file name

            FileOutputStream fileOut = new FileOutputStream(Constant.Path_TestData + Constant.File_TestData);

            excelWBook.write(fileOut);

            fileOut.flush();

            fileOut.close();

        }catch(Exception e){

            throw (e);

        }

    }

    /*************************************************************************************************
     * Authod: Deepak Sarangi
     * Function: Get Data By Sheet Name and Column Name only
     * Uses TestData path in Config file, SheetName as parameter and Columnname as Parameter
     * Returns a String
     * To Be Reviewed Against the above methods
     * Removed Static from all methods
     *
     ************************************************************************************************/

    public String getDataFromColumn(String sheetName, String columnName) throws Exception {
        String value=null;
        try {

            // Open the Excel file
            String path =FileReaderManager.getInstance().getConfigReader().getTestDataPath();
            FileInputStream ExcelFile = new FileInputStream(path);

            // Access the required test data sheet

            excelWBook = new XSSFWorkbook(ExcelFile);

            excelWSheet = excelWBook.getSheet(sheetName);
            int colNum=excelWSheet.getRow(0).getLastCellNum();
            for(int i=0;i<colNum;i++) {
                if(excelWSheet.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase(columnName)){
                    value=excelWSheet.getRow(1).getCell(i).getStringCellValue();
                    break;
                }

            }

        } catch (Exception e){

            throw (e);

        }
        return value;

    }


    /*************************************************************************************************
     * Authod: Deepak Sarangi
     * Function: Get multiple data from excelFile Data By Sheet Name and Column Name only
     * Uses TestData path in Config file, SheetName as parameter and Columnname as Parameter
     * Returns an List<String>
     * To Be Reviewed Against the above methods
     * Removed Static from all methods
     *
     ************************************************************************************************/
    public List<String> getMultipleDataFromColumn(String sheetName, String columnName) throws Exception {
        List<String> value=new ArrayList<String>();
        try {

            // Open the Excel file
            String path =FileReaderManager.getInstance().getConfigReader().getTestDataPath();
            FileInputStream ExcelFile = new FileInputStream(path);

            // Access the required test data sheet

            excelWBook = new XSSFWorkbook(ExcelFile);

            excelWSheet = excelWBook.getSheet(sheetName);
            int colNum=excelWSheet.getRow(0).getLastCellNum();
            for(int i=0;i<colNum;i++) {
                if(excelWSheet.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase(columnName)){
                    int rowNum=excelWSheet.getLastRowNum();
                    for(int j=1; j<rowNum;j++) {
                        String cellValue = excelWSheet.getRow(j).getCell(i).getStringCellValue();
                        if(!cellValue.isEmpty()){
                            value.add(cellValue);
                        }else{
                            break;
                        }


                    }
                    break;
                }

            }

        } catch (Exception e){

            throw (e);

        }
        return value;

    }

}
