package selenium;

public class wait {
    
}
