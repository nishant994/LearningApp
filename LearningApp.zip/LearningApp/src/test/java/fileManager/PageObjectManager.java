package fileManager;

import org.openqa.selenium.WebDriver;

import pageObjects.*;


public class PageObjectManager {

    private WebDriver driver;

    private TVFrontPage tvFrontPage;
    private TDCHomePage tdcHomePage;
    private MobileHomePage mobileHomePage;
    private MobileCheckoutPage mobileCheckoutPage;


    public PageObjectManager(WebDriver driver) {

        this.driver = driver;

    }

    public TVFrontPage getTvFrontPage(){
        tvFrontPage = new TVFrontPage(driver);
        return tvFrontPage;

    }

    public TDCHomePage getTDCHomePage(){
         tdcHomePage = new TDCHomePage(driver);
         return tdcHomePage;

    }


    public MobileHomePage getMobileHomePage() {
        mobileHomePage = new MobileHomePage(driver);
        return mobileHomePage;
    }

    public MobileCheckoutPage getMobileCheckoutPage() {
        mobileCheckoutPage = new MobileCheckoutPage(driver);
        return mobileCheckoutPage;
    }

}