package fileManager;

import java.io.IOException;
import java.net.URL;
import java.sql.Driver;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;

import enums.DriverType;
import enums.EnvironmentType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import utilities.GridSetup;

public class WebDriverManager {

    private  WebDriver driver;
    private static DriverType driverType;
    private static EnvironmentType environmentType;
    private static final String CHROME_DRIVER_PROPERTY = "webdriver.chrome.driver";
    private static String gridUrl;
    private GridSetup gridSetup;

    public WebDriverManager() throws IOException {
        driverType = FileReaderManager.getInstance().getConfigReader().getBrowser();
        environmentType = FileReaderManager.getInstance().getConfigReader().getEnvironment();
        gridUrl= FileReaderManager.getInstance().getConfigReader().getGridUrl();

    }

    public WebDriver getDriver() {
        if(driver == null)
            try {
                driver = createDriver();
                DriverFactory.addDriver(driver);
            }catch(IOException e){
                System.out.println("Driver initiation failed");
            }
        return driver;
    }

    private WebDriver createDriver() throws IOException {
        gridSetup =new GridSetup();
        switch (environmentType) {
            case LOCAL : driver = createLocalDriver();
                break;
            case REMOTE :
                gridSetup.setUpGrid();
                driver = createRemoteDriver();
                break;
        }
        return driver;
    }

    private WebDriver createRemoteDriver() throws IOException {
        //With default as Chrome if Invalid value is mentioned in the Config
        DesiredCapabilities dc= DesiredCapabilities.chrome();

        switch (driverType) {
            case FIREFOX:
                dc= DesiredCapabilities.firefox();
                break;
            case CHROME:
                dc= DesiredCapabilities.chrome();
                break;
            case INTERNETEXPLORER:
                dc=DesiredCapabilities.internetExplorer();
                break;

        }
        driver= new RemoteWebDriver(new URL(gridUrl),
                dc);

        if (FileReaderManager.getInstance().getConfigReader().getBrowserWindowSize())
            driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(FileReaderManager.getInstance().getConfigReader().getImplicitlyWait(), TimeUnit.SECONDS);
        return driver;
    }

        private WebDriver createLocalDriver() throws IOException {
            switch (driverType) {
                case FIREFOX:
                    driver = new FirefoxDriver();
                    break;
                case CHROME:
                    System.setProperty(CHROME_DRIVER_PROPERTY, FileReaderManager.getInstance().getConfigReader().getDriverPath());
                    //WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver();
                    break;
                case INTERNETEXPLORER:
                    driver = new InternetExplorerDriver();
                    break;
            }

            if (FileReaderManager.getInstance().getConfigReader().getBrowserWindowSize())
                driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(FileReaderManager.getInstance().getConfigReader().getImplicitlyWait(), TimeUnit.SECONDS);
            return driver;

        }

//        public static void closeDriver() {
//        System.out.println("Driver to be closed");
//        driver.close();
//        driver.quit();
//    }

}