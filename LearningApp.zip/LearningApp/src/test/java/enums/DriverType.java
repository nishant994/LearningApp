package enums;

public enum DriverType {
    CHROME,
    FIREFOX,
    INTERNETEXPLORER,
    EDGE

}
