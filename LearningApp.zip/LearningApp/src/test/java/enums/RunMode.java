package enums;

public enum RunMode {
    DOCKER
}
