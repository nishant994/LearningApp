package pageObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.AccessibilityHelper;
import utilities.CommonFunctions;
import org.openqa.selenium.JavascriptExecutor;


import java.io.IOException;
import java.util.List;

public class MobileHomePage {
    WebDriver driver;
    AccessibilityHelper aHelper = new AccessibilityHelper();
    CommonFunctions comFunc= new CommonFunctions();

    public MobileHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }

    By iPhoneIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/\"]");
    By samsungIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/samsung/\"]");
    By motorolaIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/motorola/\"]");
    By sonyIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/sony/\"]");
    By emporiaIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/emporia/\"]");
    By huaweiIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/huawei/\"]");
    By nokiaIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/nokia/\"]");
    By oneplusIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/oneplus/\"]");

    By iPhone11Pro=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-11-pro/\"]");
    By iPhone12Mini=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-12-mini/\"]");
    By iPhone12=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-12/\"]");
    By iPhone12Pro=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-12-pro/\"]");
    By iPhone12ProMax=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-12-pro-max/\"]");
    By iPhoneSe=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-se/\"]");
    By airPods=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/airpods/\"]");
    By iPhoneXsMax=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-xs-max/\"]");
    By iPhoneXr=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/iphone-xr/\"]");
    By airPodsMax=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/airpods-max/\"]");
    By airPodsWireless=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/airpods-med-trdlst-opladningsetui/\"]");
    By airPodsPro=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/airpods-pro/\"]");
    By appleWatch=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/watch-se/\"]");
    By appleSeries6=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/watch-series-6/\"]");



    By acceptButton = By.xpath("//*[@id='acceptButton']");

    By denmarkBestNetworkText = By.xpath("//*[contains(text(),'Nyhed! Nu kan du opleve 5G-hastigheder – først med YouSee')]");
    By nyhedText = By.xpath("//*[contains(text(),'Nyhed! Nu kan du opleve 5G-hastigheder – først med YouSee')]");
    By expressBankText = By.xpath("//*[contains(text(),'Betal over 12 eller 24 mdr. med YouSee/Expressbank')]");
    By expressBankInterestText = By.xpath("//*[contains(text(),'YouSee og Expressbank ratebetaling')]");
    By newTerminalText = By.xpath("//*[contains(text(),'Køb din nye mobiltelefon hos YouSee - vi tilbyder markedets bedste telefoner til skarpe priser med fri levering')]");
    By newSubscriptiontext = By.xpath("//*[contains(text(),'Altid gode tilbud på mobiltelefoner med abonnement - køb din nye smartphone med et billigt mobilabonnement hos YouSee')]");
    By subscriptionext = By.xpath("//*[contains(text(),'Oplev et hav af unikke fordele med abonnement fra YouSee')]");
    By bestMobilePhoneText = By.xpath("//*[contains(text(),'Hvilken mobiltelefon er bedst? - YouSee har et bredt udvalg af de bedste mobiltelefoner til forskellige priser')]");
    By smartPhoneOnlineText = By.xpath("//*[contains(text(),'Når du køber ny smartphone online - læs alt om bestilling, fri levering, retur- og reklamationsret')]");
    By chooseMobileHelpText = By.xpath("//*[contains(text(),'Hvilken mobiltelefon skal jeg vælge? - Find markedets bedste mobil til dig hos YouSee')]");
    By bestMobileHelpText = By.xpath("//*[contains(text(),'Hvilken mobil er bedst? - find den telefon, der passer bedst til dig')]");
    By kameraText = By.xpath("//*[contains(text(),'Kamera')]");
    By skærmText = By.xpath("//*[contains(text(),'Skærm')]");
    By styrsystemText =  By.xpath("//*[contains(text(),'Styresystem - iOS vs Android\n')]");
    By batteriText =  By.xpath("//*[contains(text(),'Batteri')]");
    By designText =  By.xpath("//*[contains(text(),'Design')]");
    By memoryText =  By.xpath("//*[contains(text(),'Hukommelse')]");
    By priceText =  By.xpath("//*[contains(text(),'Pris')]");
    By emporiaText =  By.xpath("//*[contains(text(),'Billige mobiltelefoner til ældre fra Emporia\n')]");

    By continueButton = By.xpath("//*[contains(text(),'til kurv')]");
    By basketContinueButton = By.xpath("//*[contains(text(),'bestilling')]");
    By basketDetailPageContinue = By.xpath("//*[contains(text(),'bestilling')]");


    public void navigateTo_HomePage() throws IOException {
        //  driver.get("https://yousee.dk/mobil/mobiltelefoner/");
          driver.get("http://nsum-frontend-20201211124825939800000001.s3-website.eu-central-1.amazonaws.com/mobil/mobiltelefoner/");
        //  driver.get("http://localhost:8080/mobil/mobiltelefoner/");
        //  driver.manage().deleteAllCookies();
        //  driver.findElement(By.xpath("//*[@id='clearBrowsingDataConfirm']")).click();
    }

    public void clickiPhone() throws IOException {
        driver.findElement(iPhoneIcon).click();
    }

    public void acceptCookie() {
        try {
            List<WebElement> cookieButton = driver.findElements(acceptButton);
            if (cookieButton.size() > 0)
            {
                Actions action = new Actions(driver);

                action.moveToElement(cookieButton.get(0)).click();
                Thread.sleep(6000);
            }
            driver.findElement(acceptButton).click();
        } catch ( Exception ignored) { }
    }

    public void terminalsDisplayOnHomePageContents() throws IOException{
        driver.findElement(iPhoneIcon).isDisplayed();
        driver.findElement(samsungIcon).isDisplayed();
        driver.findElement(motorolaIcon).isDisplayed();
        driver.findElement(sonyIcon).isDisplayed();
        driver.findElement(huaweiIcon).isDisplayed();
        driver.findElement(emporiaIcon).isDisplayed();
        driver.findElement(oneplusIcon).isDisplayed();
        driver.findElement(nokiaIcon).isDisplayed();

    }

    public void verifyTextsOnHomePage()throws IOException {
        driver.findElement(denmarkBestNetworkText).isDisplayed();
        driver.findElement(nyhedText).isDisplayed();
        driver.findElement(expressBankText).isDisplayed();
        driver.findElement(expressBankInterestText).isDisplayed();
        driver.findElement(newTerminalText).isDisplayed();
        driver.findElement(newSubscriptiontext).isDisplayed();
        driver.findElement(subscriptionext).isDisplayed();
        driver.findElement(bestMobilePhoneText).isDisplayed();
        driver.findElement(smartPhoneOnlineText).isDisplayed();
        driver.findElement(chooseMobileHelpText).isDisplayed();
        driver.findElement(bestMobileHelpText).isDisplayed();
        driver.findElement(kameraText).isDisplayed();
        driver.findElement(skærmText).isDisplayed();
        driver.findElement(styrsystemText).isDisplayed();
        driver.findElement(batteriText).isDisplayed();
        driver.findElement(designText).isDisplayed();
        driver.findElement(memoryText).isDisplayed();
        driver.findElement(priceText).isDisplayed();
        driver.findElement(emporiaText).isDisplayed();
    }

    public void verifyAllAppleProducts() throws IOException{
        driver.findElement(iPhone11Pro).isDisplayed();
        driver.findElement(iPhone12).isDisplayed();
        driver.findElement(iPhone12Pro).isDisplayed();
        driver.findElement(iPhone12ProMax).isDisplayed();
        driver.findElement(iPhoneSe).isDisplayed();
        driver.findElement(airPods).isDisplayed();
        driver.findElement(iPhoneXsMax).isDisplayed();
        driver.findElement(iPhoneXr).isDisplayed();
        driver.findElement(airPodsMax).isDisplayed();
        driver.findElement(airPodsWireless).isDisplayed();
        driver.findElement(airPodsPro).isDisplayed();
        driver.findElement(appleWatch).isDisplayed();
        driver.findElement(appleSeries6).isDisplayed();

    }

    public void clickiPhone12() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(iPhone12).click();
        comFunc.jsexecutor(continueButton);
        comFunc.jsexecutor(basketContinueButton);
        Thread.sleep(2000);
        comFunc.jsexecutor(basketDetailPageContinue);
        Thread.sleep(2000);
    }
}
