package pageObjects;

import org.openqa.selenium.WebDriver;

public class BaseTest {
    WebDriver driver;
    public BaseTest(WebDriver driver){

    }
}
