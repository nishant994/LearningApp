package pageObjects;

import gherkin.lexer.Th;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import utilities.AccessibilityHelper;
import utilities.CommonFunctions;

import java.io.IOException;
import java.util.List;

public class MobileCheckoutPage {
    WebDriver driver;
    AccessibilityHelper aHelper = new AccessibilityHelper();
    CommonFunctions comFunc= new CommonFunctions();

    public MobileCheckoutPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }

    By iPhoneIcon=By.xpath("//*[@href=\"/mobil/mobiltelefoner/apple/\"]");
    By acceptButton = By.xpath("//*[@id='acceptButton']");
    By skærmText = By.xpath("//*[contains(text(),'Skærm')]");
    // By continueButton = By.xpath("//*[contains(text(),'til kurv')]");
    By basketContinueButton = By.xpath("//*[contains(text(),'bestilling')]");
    By basketDetailPageContinue = By.xpath("//*[contains(text(),'til bestilling')]");

    private By nyttNummer = By.xpath("//*[contains(text(),'Nyt nummer')]");
    private By secretNummer = By.xpath("//*[contains(text(),'hemmeligt')]");
    private By coContinueButton = By.xpath("//*[contains(text(),'Fortsæt')]");
    private By nemIdClose = By.xpath("//*[@class='cancel__image']");
    private By cprInput = By.name("ssn");
    By telephoneNumber = By.xpath("//*[@placeholder='Indtast telefonnummer']");
    By emailAdd = By.xpath("//*[@placeholder='Indtast e-mailadresse']");
    By deliverText = By.xpath("//*[contains(text(),'Send til min hjemmeadresse')]");
    By collectAtshopText = By.xpath("//*[contains(text(),'Hent i butik')]");
    By deliveryConButton = By.xpath("//*[@class='component-button__button']");



    /*
    * nyttNummer
    * telfonNummer
    * simKortNummer
    * secretNummer
    * continueButton
    *
    * */


    public void coNewSecretNum() throws InterruptedException {
        Thread.sleep(3000);
     //   driver.findElement(nyttNummer).click();
        comFunc.jsexecutor(nyttNummer);
        comFunc.jsexecutor(secretNummer);
        Thread.sleep(5000);
        comFunc.jsexecutor(coContinueButton);
        comFunc.jsexecutor(coContinueButton);
        Thread.sleep(5000);
    }

    public void coNemIdStep() throws InterruptedException {
        try {

        comFunc.jsexecutor(nemIdClose);
          comFunc.jsexecutor(cprInput);
          comFunc.typeText(cprInput,"1111111111");
      } catch (Exception e){}
      //  Thread.sleep(3000);
        comFunc.jsexecutor(telephoneNumber);
        comFunc.typeText(telephoneNumber,"12345678");
        comFunc.typeText(emailAdd,"arjatest@tdc.dk");
        comFunc.jsexecutor(coContinueButton);
        Thread.sleep(2000);
       // comFunc.jsexecutor(collectAtshopText);
       //  Thread.sleep(8000);
        driver.findElement(deliveryConButton).isDisplayed();
        driver.findElement(deliveryConButton).click();
       // comFunc.jsexecutor(deliveryConButton);
        Thread.sleep(2000);

    }
}
