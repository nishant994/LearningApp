package pageObjects;

import fileManager.FileReaderManager;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import utilities.AccessibilityHelper;

import java.io.IOException;

public class TVFrontPage {
    WebDriver driver;
    AccessibilityHelper aHelper = new AccessibilityHelper();

    public TVFrontPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    By addressBar = By.xpath("//input[@placeholder = 'Indtast dit vejnavn og husnr.']");
    By autocompleteAddress = By.xpath("//div[@class = 'autocomplete__container']/ul/li/span");


    By productPage = By.xpath("//div[@class ='sales-card-tv__product-title-points mb-3 mb-sm-0']");

    public void navigateTo_HomePage() throws IOException {
        driver.get(FileReaderManager.getInstance().getConfigReader().getApplicationUrl());
    }

    public void setAddress(String address) throws IOException {
        driver.findElement(addressBar).sendKeys(address);


    }

    public void clickOnAddressFromDropdown(){
        driver.findElement(autocompleteAddress).click();

    }
    public void VerifyProductPage(){
        boolean present;
        try {
            driver.findElement(By.xpath("productPage"));
            present = true;
        } catch (NoSuchElementException e) {
            present = false;
        }

    }

    //Added by Deepak for accessibility demo
    public String verifyAccesibility(){
        String s = aHelper.testAccessibility(driver);
        //System.out.println(s);

        return s;
    }

    //Added by deepak for parallel executions
    public void visitUrl(){
        driver.get("https://t25-salg.internal.yousee.dk/tv");
    }


}