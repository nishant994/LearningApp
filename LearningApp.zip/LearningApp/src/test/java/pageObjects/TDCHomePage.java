package pageObjects;

import fileManager.FileReaderManager;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.AccessibilityHelper;
import utilities.CommonFunctions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TDCHomePage {
    WebDriver driver;
    AccessibilityHelper aHelper = new AccessibilityHelper();
    CommonFunctions comFunc= new CommonFunctions();

    public TDCHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }
    @FindBy(xpath = "//button[text()='ACCEPTER ALLE COOKIES']")
    public List<WebElement> acceptCookieBtnList;

    @FindBy(xpath = "//a[@class='top-menu__link'][text()='Produkter']")
    public WebElement productLink;

    @FindBy(xpath = "//a[@class='submenu__link']/*[contains(text(),'Mobilabonnement')]/..")
    public WebElement mobileSubscriptionLink;

    public By productLinktxt= By.xpath("//a[@class='top-menu__link'][text()='Produkter']");


    public void navigateTo_HomePage() throws IOException {
        //driver.get(FileReaderManager.getInstance().getConfigReader().getApplicationUrl());
        driver.get("https://www.tdc.dk");
    }

    public CommonFunctions getComFunc(){
        return comFunc;
    }


    public void acceptCookie(){
        if(acceptCookieBtnList.size()>0){
           acceptCookieBtnList.get(0).click();
        }


    }

    public void navigateToMobileSubscriptionPage(){
//        productLink.click();
        comFunc.clickElement(productLinktxt);



        mobileSubscriptionLink.click();
    }

    public boolean verifyPage(String expectedTitle){
        String actualTitle =driver.getTitle();
        boolean pageMatch=false;
        if(actualTitle.equalsIgnoreCase(expectedTitle)){
            pageMatch=true;
        }
        return pageMatch;


    }



    //Added by deepak for parallel executions
    public void visitUrl(){
        driver.get("https://t25-salg.internal.yousee.dk/tv");
    }


}