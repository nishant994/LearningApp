package stepDefinitions;

import Cucumber.TestContext;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pageObjects.BasePage;
import pageObjects.TDCHomePage;
import pageObjects.TVFrontPage;
import pageObjects.TVProductPage;

import java.io.IOException;

public class TVStepDefinitions {
    TVFrontPage tvFrontPage;
    TestContext testContext;
    TDCHomePage tdcHomePage;
    WebDriver driver;


    public TVStepDefinitions(TestContext context) throws IOException {
        testContext = context;
        tdcHomePage = testContext.getPageObjectManager().getTDCHomePage();
        tvFrontPage=testContext.getPageObjectManager().getTvFrontPage();

    }


    @And("wait for {int} secs for page to load")
    public void waitForSecsForPageToLoad(int timeInSecs) throws InterruptedException {
        Thread.sleep(timeInSecs);
    }

    @Given("user is on the homepage of yousee TV")
    public void userIsOnTheHomepageOfYousee() throws IOException {
        tvFrontPage.navigateTo_HomePage();
    }

    @Then("the user is navigated to the product page")
    public void theUserIsNavigatedToTheProductPage() {
        tvFrontPage.VerifyProductPage();

    }

    @And("the list of products should be displayed specific to the user address")
    public void theListOfProductsShouldBeDisplayedSpecificToTheUserAddress() {

    }

    @When("user enters the address as {string}")
    public void userEntersTheAddressAs(String addressForTV) throws IOException {
        tvFrontPage.setAddress(addressForTV);
        //tvFrontPage.clickOnAddressFromDropdown();
    }

    @Then("^We check accessibility of the page$")
    public void we_check_accessibility_of_the_page() {
    tvFrontPage.verifyAccesibility();
    }

    @Given("user visits Yousee Homepage")
    public void userVisitsYouseeHomepage() {
        tvFrontPage.visitUrl();
    }


}

