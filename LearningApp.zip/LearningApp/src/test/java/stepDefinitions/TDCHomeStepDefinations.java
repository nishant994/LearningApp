package stepDefinitions;

import Cucumber.TestContext;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pageObjects.BasePage;
import pageObjects.TDCHomePage;
import pageObjects.TVFrontPage;
import utilities.CommonFunctions;
import utilities.Reporter;


import java.io.IOException;

import static org.testng.Assert.assertTrue;

public class TDCHomeStepDefinations {
    TVFrontPage tvFrontPage;
    TDCHomePage tdcHomePage;
    TestContext testContext;
    BasePage basePage;
    WebDriver driver;
    Scenario scenario;
    CommonFunctions comFunc;
    Reporter reporter;



    public TDCHomeStepDefinations(TestContext context) {
        testContext = context;
        tdcHomePage = testContext.getPageObjectManager().getTDCHomePage();
        tvFrontPage=testContext.getPageObjectManager().getTvFrontPage();
        reporter = new Reporter();
    }



    @Before
    public void setupScenario(Scenario s){
        scenario=s;
    }

    @Given("^user visits TDC Homepage$")
    public void user_visits_tdc_homepage() throws Throwable {
        tdcHomePage.navigateTo_HomePage();
        reporter.addScreenshot(scenario,"before cookies");

    }


    @And("^User accepts the cookie in the banner$")
    public void user_accepts_the_cookie_in_the_banner() throws Throwable {
        tdcHomePage.acceptCookie();
        reporter.logText(scenario,"Cookie accepted");

    }
    @When("^User navigate to MobileSubscription page$")
    public void user_navigate_to_mobilesubscription_page() throws Throwable {
        tdcHomePage.navigateToMobileSubscriptionPage();
        reporter.logBoldText(scenario,"Clicked on mobile subscription link");
        reporter.logCurrentUrl(scenario,"mobilePage");

    }

    @Then("^the Page title should match$")
    public void the_page_title_should_match() throws Throwable {
       assertTrue(tdcHomePage.verifyPage("TDC Erhverv One+ | Mobilabonnementer - TDC Erhverv"));

    }

}

