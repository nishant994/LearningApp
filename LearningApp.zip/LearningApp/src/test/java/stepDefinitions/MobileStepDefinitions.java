package stepDefinitions;

import Cucumber.TestContext;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.bytebuddy.implementation.bytecode.Throw;
import org.openqa.selenium.WebDriver;
import pageObjects.*;
import utilities.CommonFunctions;
import utilities.Reporter;

import java.security.PublicKey;

public class MobileStepDefinitions {
    MobileHomePage mobileHomePage;
    MobileCheckoutPage mobileCheckoutPage;
    BasePage basePage;
    WebDriver driver;
    Scenario scenario;
    CommonFunctions commonFunctions;
    Reporter reporter;
    TestContext testContext;

    public MobileStepDefinitions(TestContext context) {
         testContext = context;
         mobileHomePage = testContext.getPageObjectManager().getMobileHomePage();
         mobileCheckoutPage = testContext.getPageObjectManager().getMobileCheckoutPage();
         reporter = new Reporter();
    }

    @Before
    public void setupScenario(Scenario s) {
        scenario = s;
    }

    @Given("^user visits mobile homepage")
    public void user_visit_mobile_homepage() throws Throwable {
        mobileHomePage.navigateTo_HomePage();
        reporter.addScreenshot(scenario,"before cookies");
    }

    @Then("^user clicks on iPhone")
    public void user_clicks_iPhone() throws Throwable {
        mobileHomePage.clickiPhone();
        reporter.addScreenshot(scenario,"iPhone homepage");
    }

    @And("^user accepts cookies")
    public void user_accepts_cookies() throws Throwable {
        mobileHomePage.acceptCookie();
    }

    @Then("^verify terminals display on homepage")
    public void verify_terminal_displays_contents() throws Throwable {
        mobileHomePage.terminalsDisplayOnHomePageContents();
    }

    @And("^verify texts contents on homepage")
    public void verify_texts_homePage() throws Throwable {
        mobileHomePage.verifyTextsOnHomePage();
    }

    @Then("^verify all apple terminals watches and airpods")
    public void verify_all_apple_products() throws Throwable {
        mobileHomePage.verifyAllAppleProducts();
    }

    @Given("^user is on apple terminal page")
    public void user_on_apple_page() throws Throwable {
        mobileHomePage.navigateTo_HomePage();
        mobileHomePage.acceptCookie();
        mobileHomePage.clickiPhone();
    }

    @Given("^user choose an iphone12 and click continue")
    public void choose_iPhone() throws Throwable {

        mobileHomePage.clickiPhone12();
        mobileCheckoutPage.coNewSecretNum();
        mobileCheckoutPage.coNemIdStep();


    }


}
