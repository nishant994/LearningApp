package utilities;

public class Log {
}
