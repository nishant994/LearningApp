package utilities;

import fileManager.DriverFactory;
import io.cucumber.java.Scenario;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonFunctions {

    public CommonFunctions() {
        this.driver = DriverFactory.getDriver();
    }

    WebDriver driver;
    WebDriverWait wait;

    public void clickElement(By by){
        WebElement element=waitForElementClickable(by);
        element.click();

    }

    public WebElement waitForElementClickable(By by){
        wait=new WebDriverWait(driver, 10);
        return wait.until(ExpectedConditions.elementToBeClickable(by));

    }

    public void typeText(By by, String text){
        WebElement element= waitTillElementVisible(by);
        element.clear();
        element.sendKeys(text);
    }

    public WebElement waitTillElementVisible(By by){
        wait=new WebDriverWait(driver, 10);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));

    }

    public String getText(By by){
        WebElement element= waitTillElementVisible(by);
        return element.getText();
    }

    public String getAttribute(By by, String attribute){
        WebElement element= waitTillElementVisible(by);
        String value = element.getAttribute(attribute);
        return value;
    }

    public void selectByIndex(By by, int index){
        Select select= new Select(waitTillElementVisible(by));
        select.deselectAll();
        select.selectByIndex(index);

    }

    public void jsexecutor(By by) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement byElement = driver.findElement(by);
        js.executeScript("arguments[0].click();",byElement);

    }

    public void selectByValue(By by, String value){
        Select select= new Select(waitTillElementVisible(by));
        select.deselectAll();
        select.selectByValue(value);

    }

    public void selectByText(By by, String text){
        Select select= new Select(waitTillElementVisible(by));
        select.deselectAll();
        select.selectByVisibleText(text);

    }

    public boolean isDisplayed(By by){
        WebElement element;
        boolean isDisplayed;
        try {
            element= waitTillElementVisible(by);
            isDisplayed=element.isDisplayed();
        }catch(Exception e) {
            isDisplayed=false;
        }

        return isDisplayed;
    }

    public boolean isSelected(By by){
        WebElement element;
        boolean isChecked;
        try {
            element= waitTillElementVisible(by);

            isChecked=element.isSelected();
        }catch(Exception e) {
            isChecked=false;
        }


        return isChecked;
    }

    public boolean isEnabled(By by){
        WebElement element;
        boolean isEnabled;
        try {
            element= waitTillElementVisible(by);

            isEnabled=element.isEnabled();
        }catch(Exception e) {
            isEnabled=false;
        }
        return isEnabled;
    }

}
