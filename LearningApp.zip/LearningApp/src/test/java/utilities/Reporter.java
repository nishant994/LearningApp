package utilities;

import fileManager.DriverFactory;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Reporter {

    private  WebDriver driver;

    public Reporter(){this.driver= DriverFactory.getDriver();    }
    public void addScreenshot(Scenario scenario, String text){

        byte[] b= takeScreenshot();
        scenario.attach(b,"image/png",text);
    }
    public void logText(Scenario scenario,String text){
        scenario.log(text);
    }

    public byte[] takeScreenshot() {

        byte[] b =((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        return b;
    }
    public void logBoldText(Scenario scenario, String text){
        scenario.log("<b>"+text+"</b>");
    }

    public void logCurrentUrl(Scenario scenario, String ... tag){
        String url=driver.getCurrentUrl();
        if(tag.length>0){


            scenario.log("<a href="+url+">"+tag[0]+"</a>");
        }else{
            scenario.log("<a href="+url+">"+url+"</a>");
        }
    }
}
