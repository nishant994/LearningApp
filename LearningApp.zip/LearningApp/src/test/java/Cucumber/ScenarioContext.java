package Cucumber;

public class ScenarioContext {

}
