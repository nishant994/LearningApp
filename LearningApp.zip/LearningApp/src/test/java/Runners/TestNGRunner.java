package Runners;


import fileManager.WebDriverManager;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.*;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import utilities.GridSetup;


@CucumberOptions(tags = "@int-test1", monochrome = true,
        features = {"src\\resources\\Features\\"},
        dryRun = false,
        glue = "stepDefinitions",
        plugin = { "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "json:target/cucumber/cucumber.json"}

)
class TestNGRunner extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }

    @BeforeClass
    public static void setUpTest(){
    }


    @AfterClass
   public static void teardown() throws Exception {

        GridSetup.gridCleanUp();

    }


}
