package Runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(tags = "@int-test1", monochrome = true,
        features = {"\\NSU-Test-Automation\\src\\resources\\Features\\"},
        dryRun = false,
        glue = "stepDefinitions",
        plugin = {"pretty", "html:target/site/cucumber-pretty.html", "json:target/cucumber/cucumber.json"}

)
public class TestRunner {

}
